import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouterModule,Routes } from '@angular/router';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { RegistrationComponent } from './registration/registration.component';
import { DoctorsComponent } from './doctors/doctors.component';
import { Book1Component } from './book1/book1.component';
import { Book2Component } from './book2/book2.component';
import { ContactusComponent } from './contactus/contactus.component';
import { FeedbackComponent } from './feedback/feedback.component';
import { TestComponent } from './example1';
import { RegistrationforcabComponent } from './registrationforcab/registrationforcab.component';
import { LoginforcabComponent } from './loginforcab/loginforcab.component';
import { BookacabComponent } from './bookacab/bookacab.component';
import { ContactusforcabComponent } from './contactusforcab/contactusforcab.component';
import { FeedbackforcabComponent } from './feedbackforcab/feedbackforcab.component';
import { RegistrationforhotelComponent } from './registrationforhotel/registrationforhotel.component';
import { LoginforhotelComponent } from './loginforhotel/loginforhotel.component';
import { BookingahotelComponent } from './bookingahotel/bookingahotel.component';
import { ContactusforhotelComponent } from './contactusforhotel/contactusforhotel.component';
import { FeedbackforhotelComponent } from './feedbackforhotel/feedbackforhotel.component';
import { FormsModule } from '@angular/forms';
import { IfDemoComponent } from './if-demo/if-demo.component';
import { FordemoComponent } from './fordemo/fordemo.component';
import { ImageIfComponent } from './image-if/image-if.component';
import { PipeDemoComponent } from './pipe-demo/pipe-demo.component';
import { PipeDemoFirstComponent } from './pipe-demo-first/pipe-demo-first.component';
import { CustomPipeComponent } from './custom-pipe/custom-pipe.component';
import {Additionpipe} from './custom-pipe/custom-pipe.addition';
import { CustomPipeFirstComponent } from './custom-pipe-first/custom-pipe-first.component';
import { Sentancepipe } from './custom-pipe-first/custom-pipe-first.sentence';
import { LikeDemoComponent } from './like-demo/like-demo.component';

const appRoutes: Routes=[
  {path:'registrationforhotel',component:RegistrationforhotelComponent},
  {path:'loginforhotel',component:LoginforhotelComponent},
  {path:'bookingahotel',component:BookingahotelComponent},
  {path:'contactusforhotel',component:ContactusforhotelComponent},
  {path:'feedbackforhotel',component:FeedbackforhotelComponent},
  ];

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    RegistrationComponent,
    DoctorsComponent,
    Book1Component,
    Book2Component,
    ContactusComponent,
    FeedbackComponent,
    TestComponent,
    RegistrationforcabComponent,
    LoginforcabComponent,
    BookacabComponent,
    ContactusforcabComponent,
    FeedbackforcabComponent,
    RegistrationforhotelComponent,
    LoginforhotelComponent,
    BookingahotelComponent,
    ContactusforhotelComponent,
    FeedbackforhotelComponent,
    IfDemoComponent,
    FordemoComponent,
    ImageIfComponent,
    PipeDemoComponent,
    PipeDemoFirstComponent,
    CustomPipeComponent,
    Additionpipe,
    CustomPipeFirstComponent,
    Sentancepipe,
    LikeDemoComponent
  ],

  imports: [
    FormsModule,
    BrowserModule,
    AppRoutingModule,
    RouterModule.forRoot(appRoutes)
  ],
  providers: [],
  bootstrap: [LikeDemoComponent ]
})
export class AppModule { }

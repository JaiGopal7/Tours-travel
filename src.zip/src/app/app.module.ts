import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { CapchaService } from './login/login.service';
import { RegistrationComponent } from './registration/registration.component';
import { RouterModule,Routes } from '@angular/router';
import { ContactusComponent } from './contactus/contactus.component';
import { FeedbackComponent } from './feedback/feedback.component';
import { AboutusComponent } from './aboutus/aboutus.component';
import { HomeComponent } from './home/home.component';
import { FlightComponent } from './flight/flight.component';
import { TrainComponent } from './train/train.component';
import { BusComponent } from './bus/bus.component';
import { CabComponent } from './cab/cab.component';
import { HotelComponent } from './hotel/hotel.component';
import { HomestayComponent } from './homestay/homestay.component';



const appRoutes: Routes=[
  {path:'Registration',component:RegistrationComponent},
  {path:'Login',component:LoginComponent},
  {path:'Contactus',component:ContactusComponent},
  {path:'Feedback',component:FeedbackComponent},
  {path:'Aboutus',component:AboutusComponent},
  {path:'Flight',component:FlightComponent},
  {path:'Train',component:TrainComponent},
  {path:'Bus',component:BusComponent},
  {path:'Cab',component:CabComponent},
  {path:'Hotel',component:HotelComponent},
  {path:'Homestay',component:HomestayComponent},
  {path:'Home',component:HomeComponent},
  ];


@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    RegistrationComponent,
    ContactusComponent,
    FeedbackComponent,
    AboutusComponent,
    HomeComponent,
    FlightComponent,
    TrainComponent,
    BusComponent,
    CabComponent,
    HotelComponent,
    HomestayComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    RouterModule.forRoot(appRoutes)
  ],
  providers: [ CapchaService ],
  bootstrap: [ AppComponent  ]
})
export class AppModule { }

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-book1',
  templateUrl: './book1.component.html',
  styleUrls: ['./book1.component.css']
})
export class Book1Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

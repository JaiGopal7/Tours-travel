import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-book2',
  templateUrl: './book2.component.html',
  styleUrls: ['./book2.component.css']
})
export class Book2Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bookacab',
  templateUrl: './bookacab.component.html',
  styleUrls: ['./bookacab.component.css']
})
export class BookacabComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

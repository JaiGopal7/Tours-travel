import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bookingahotel',
  templateUrl: './bookingahotel.component.html',
  styleUrls: ['./bookingahotel.component.css']
})
export class BookingahotelComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

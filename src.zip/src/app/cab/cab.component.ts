import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cab',
  templateUrl: './cab.component.html',
  styleUrls: ['./cab.component.css']
})
export class CabComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-contactusforcab',
  templateUrl: './contactusforcab.component.html',
  styleUrls: ['./contactusforcab.component.css']
})
export class ContactusforcabComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

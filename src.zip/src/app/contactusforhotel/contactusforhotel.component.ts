import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-contactusforhotel',
  templateUrl: './contactusforhotel.component.html',
  styleUrls: ['./contactusforhotel.component.css']
})
export class ContactusforhotelComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

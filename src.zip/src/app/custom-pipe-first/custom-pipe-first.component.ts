import { Component} from '@angular/core';

@Component({
  selector: 'app-custom-pipe-first',
  templateUrl: './custom-pipe-first.component.html',
})
export class CustomPipeFirstComponent 
{
  public msg='welcome To Angular-10';
}
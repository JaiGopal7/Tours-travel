import { Pipe, PipeTransform } from '@angular/core';
@Pipe({ name: 'Sentance' })

export class Sentancepipe implements PipeTransform 
{
    transform(str: string): string {
        let firstChar = str.charAt(0);
        let restChar = str.substring(1);
        let sentance = firstChar.toUpperCase() + restChar.toLowerCase();
        return sentance;
    }
}
import {Pipe,PipeTransform} from '@angular/core';
@Pipe({name:'Addition'})

export class Additionpipe implements PipeTransform
{
    transform(value: number, Addition: number):number 
    {
        return Addition + value;
    }
}
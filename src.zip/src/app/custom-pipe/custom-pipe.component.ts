import { Component } from '@angular/core';

@Component({
  selector: 'app-custom-pipe',
  template:`  
  <p>The Result is {{51|Addition:20}}</p><br>
  <p>The Result is {{15|Addition:74}}</p><br>
  <p>The Result is {{78|Addition:96}}</p><br>
  <p>The Result is {{86|Addition:1524}}</p><br>
  `
})
export class CustomPipeComponent {}

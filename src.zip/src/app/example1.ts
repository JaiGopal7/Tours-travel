import {Component} from '@angular/core';
@Component({
selector:'app-jai',
template:`
<p>Hello my name is {{name}}</p>
<p>Hello my email is {{email}}</p>
<p>My address is {{address.street}}{{address.loc}}
{{address.city}}{{address.state}}</p>
<p><Button (click)="sayName()">Say your Details</Button></p>
`
})
export class TestComponent
{
    name:string;
    email:string;
    address:any;
constructor()
{
    this.name='Jai Gopal Karnani';
    this.email='jai.karnani@mphasis.com';
    this.address=
    {
        street:'New Line',
        loc:'Karnani Mohalla',
        city:'Bikaner',
        state:'Rajasthan'
    
    }}
        sayName()
    {
        console.log("My name is ",this.name);
        console.log("My email is ",this.email);
        console.log("My address is ",this.address);
    }
}
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-feedbackforcab',
  templateUrl: './feedbackforcab.component.html',
  styleUrls: ['./feedbackforcab.component.css']
})
export class FeedbackforcabComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

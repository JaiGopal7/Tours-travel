import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-feedbackforhotel',
  templateUrl: './feedbackforhotel.component.html',
  styleUrls: ['./feedbackforhotel.component.css']
})
export class FeedbackforhotelComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

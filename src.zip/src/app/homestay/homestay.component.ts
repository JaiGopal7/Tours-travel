import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-homestay',
  templateUrl: './homestay.component.html',
  styleUrls: ['./homestay.component.css']
})
export class HomestayComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

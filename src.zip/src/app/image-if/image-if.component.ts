import { Component} from '@angular/core';

@Component({
  selector: 'app-image-if',
  templateUrl: './image-if.component.html',
  styleUrls: ['./image-if.component.css']
})
export class ImageIfComponent  
{
  public product1=
  {
    Name:'Adidas Shoes',
    Price:15000.00,
    Photo:'assets/shoes1.jpg'
  };

  public product2=
  {
    Name:'Levis Jeans',
    Price:2500.00,
    Photo:'assets/jeans.jpg'
  };

  public product3=
  {
    Name:'Speaker',
    Price:25000.00,
    Photo:'assets/speaker.jpg'
  };

  public showImage = false;
  public btnText = 'Show';

  public TogglePreview1()
  {
    this.showImage = (this.showImage==false)?true:false;
    this.btnText = (this.btnText=='Show')?'Hide':'Show';
  }
  public TogglePreview2()
  {
    this.showImage = (this.showImage==false)?true:false;
    this.btnText = (this.btnText=='Show')?'Hide':'Show';
  }
  public TogglePreview3()
  {
    this.showImage = (this.showImage==false)?true:false;
    this.btnText = (this.btnText=='Show')?'Hide':'Show';
  }

}


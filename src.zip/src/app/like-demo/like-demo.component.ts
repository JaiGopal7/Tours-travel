import { Component } from '@angular/core';

@Component({
  selector: 'app-like-demo',
  templateUrl: './like-demo.component.html',
  styleUrls: ['./like-demo.component.css']
})
export class LikeDemoComponent 
{
  public products = [
    { Name: 'JBL speaker', Photo: 'assets/jbl.jpg', Likes: 0, Dislikes: 0 },
    { Name: 'Nike Shoes', Photo: 'assets/nike.jpg', Likes: 0, Dislikes: 0 },
    { Name: 'shirt', Photo: 'assets/shirt.jpg', Likes: 0, Dislikes: 0 }
  ];
  public LikesCounter(item: any) 
  {
    item.Likes++;
  }
  public DislikesCounter(item: any) 
  {
    item.Dislikes++;
  }

}
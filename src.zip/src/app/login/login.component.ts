import { Component } from '@angular/core';
import { CapchaService } from './login.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent 
{
  constructor (private cap: CapchaService) { }
    public code = this.cap.GenerateService();
    public refreshClick() 
    {
      this.code = this.cap.GenerateService();
    }
}
  

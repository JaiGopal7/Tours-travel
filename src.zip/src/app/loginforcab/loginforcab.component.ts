import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-loginforcab',
  templateUrl: './loginforcab.component.html',
  styleUrls: ['./loginforcab.component.css']
})
export class LoginforcabComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

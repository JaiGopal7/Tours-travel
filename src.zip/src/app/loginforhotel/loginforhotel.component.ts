import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-loginforhotel',
  templateUrl: './loginforhotel.component.html',
  styleUrls: ['./loginforhotel.component.css']
})
export class LoginforhotelComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

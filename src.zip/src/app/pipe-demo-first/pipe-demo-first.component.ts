import { Component} from '@angular/core';

@Component({
  selector: 'app-pipe-demo-first',
  templateUrl: './pipe-demo-first.component.html',
  styleUrls: ['./pipe-demo-first.component.css']
})
export class PipeDemoFirstComponent {
  Name: string = 'Sai Gopal';
  Namelist: string[] = ["bibhudatta", "Madhavi", "sahil"]
  public product =
    {
      Name: 'Samsung TV',
      Price: 45000.00,
      Mfd: new Date('01-10-2022')
    }
}
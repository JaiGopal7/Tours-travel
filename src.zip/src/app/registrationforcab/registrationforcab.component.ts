import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-registrationforcab',
  templateUrl: './registrationforcab.component.html',
  styleUrls: ['./registrationforcab.component.css']
})
export class RegistrationforcabComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-registrationforhotel',
  templateUrl: './registrationforhotel.component.html',
  styleUrls: ['./registrationforhotel.component.css']
})
export class RegistrationforhotelComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
